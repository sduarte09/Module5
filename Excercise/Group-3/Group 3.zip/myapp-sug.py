#   GROUP 3                                      MODULE 5 EXERCISE 2                                            DATE: 04/03/2022

# IBRAHIM MIFLAL FAYAZ          -       1076485
# OMESH PERSAUD                 -       1089283
# JORGE DIAZ                    -       1073444
#------------------------------------------------DESIGN OF GUI FOR SUGAWARA MODEL-----------------------------------------------------------

#------------------------------------------------------IMPORTING OF LIBRARIES-----------------------------------------------------------------
from multiprocessing.sharedctypes import Value
from turtle import color
from bokeh.io import output_file, show, curdoc
from bokeh.layouts import widgetbox, gridplot, Row, Column, layout
from bokeh.models import CustomJS, Dropdown, VArea, ColumnDataSource
from bokeh.models.widgets import  Slider, Button, TextInput, RadioButtonGroup, PreText, Div
from bokeh.palettes import Viridis3
from bokeh.plotting import figure
import pandas as pd
import sugawara
import numpy as np
#--------------------------------------------------------------------------------------------------------------------------------------------

#------------------------------------------------------DESCRIPTIVE TEXT-----------------------------------------------------------------
description_1 = PreText(text="""SUGAWARA TANK MODEL""",width=20, height=40, style={'font-size':'20pt', 
                     'color': 'black', 
                     'font-weight': 'bold'})

text_1      = Div(text="<b><br> Please enter state variables S1 and S2. (Move sliders to Run the Model)<br></b>", visible=True) 

text_2      = Div(text="<b><br> Please enter Parameters for Discharge Coefficients.<br></b>", visible=True) 

text_3      = Div(text="<b><br> Please enter Tank Positions.<br></b>", visible=True) 

text_4      = Div(text="<b><br> Extra Parameters for Simulation.<br></b>", visible=True) 

text_5      = Div(text="<b><br> Plots from the Model.<br></b>", visible=True) 
 
#--------------------------------------------------------------------------------------------------------------------------------------------

#------------------------------------------------------STATE VARIABLES------------------------------------------------------------------
state_1 = Slider(start=0, end=30, value= 15, step=1, title="S1: Level of the top tank [mm]", visible=True)

state_2 = Slider(start=0, end=30, value= 20, step=1, title="S2: Level of the bottom tank [mm]", visible=True)
#--------------------------------------------------------------------------------------------------------------------------------------------

#---------------------------------------------Parameters for Discharge Coefficients-------------------------------------------------------
parameter_1 = Slider(start=0, end=1, value= 0.5, step=0.01, format = '0.000', title= "k1: Upper tank upper discharge coefficient", visible=True)
parameter_2 = Slider(start=0, end=1, value= 0.2, step=0.01, format = '0.000', title= "k2: Upper tank lower discharge coefficient", visible=True)
parameter_3 = Slider(start=0, end=1, value= 0.01, step=0.01, format = '0.000', title= "k3: Percolation to lower tank coefficient", visible=True)
parameter_4 = Slider(start=0, end=1, value= 0.1, step=0.01, format = '0.000', title= "k4: Lower tank discharge coefficien", visible=True)

#--------------------------------------------------------------------------------------------------------------------------------------------

#---------------------------------------------Tank Positions-------------------------------------------------------
d_position_1 = Slider(start=0, end=20, value= 10, step=0.01, format = '0.00', title= "d1: Upper tank upper discharge position", visible=True)
d_position_2 = Slider(start=0, end=30, value= 20, step=0.01, format = '0.00', title= "d2: Upper tank lower discharge positio", visible=True)

extra_param_1 = Slider(start=0, end=2, value= 1, step = 0.1 , format = '0.00', title= "DT: Number of hours in the time step [s]", visible=True)
extra_param_2 = Slider(start=100, end=200, value= 145, step= 1 , format = '0.00', title= "A: Catchment Area [km^2]", visible=True)
no_runs = Slider(start=2, end=25, value= 5, step= 1 , title= "No. of Runs", visible=True)
#---------------------------------------------Graph-------------------------------------------------------
p1 = figure(plot_width= 1200, plot_height=250, title= "Recorded Discharge vs Simulated Discharge ", x_axis_label= 'Time (h)', y_axis_label='Discharge (m^3/s)')
p2 = figure(plot_width= 1200, plot_height=250, title= "Recorded Discharge and Montecarlo Simulation ", x_axis_label= 'Time (h)', y_axis_label='Discharge (m^3/s)')
p3 = figure(plot_width= 1200, plot_height=250, title= "Error between Recorded Discharge and Simulation ", x_axis_label= 'Time (h)', y_axis_label='Discharge (m^3/s)')


#---------------------------------------------Run Button------------------------------------------------------------------------------------------
#run_widget  = Button(label="Run", button_type="danger", visible = True)
refresh_widget  = Button(label="Refresh", button_type="primary", visible = True)

# #--------------------------------------------------------------------------------------------------------------------------------------------
def sug_model(a,b,c): 
        k1 =    float(parameter_1.value)
        k2 =    float(parameter_2.value)
        k3 =    float(parameter_3.value)
        k4 =    float(parameter_4.value)
        d1 =    float(d_position_1.value)
        d2 =    float(d_position_2.value)
        rfcf =  float(extra_param_1.value)
        ecorr = float(extra_param_1.value)

        ### Read the output.asc file
        skip_rows = 16  # Number of rows to skip in the output file
        output_file = 'output.asc' # Name of the output file

        # Read data from the output file
        data = pd.read_csv(output_file,
                        skiprows=skip_rows,
                        skipinitialspace=True,
                        index_col='Time')

        # Create vector with time stamps
        time_index = pd.date_range('1994 12 07 20:00', periods=len(data), freq='H')

        # Add time stamps to observations
        data.set_index(time_index, inplace=True)
        Qrec = data.iloc[:,3]
        # define the set of extra parameters
        extra_pars = [1, 147] # time factor and area
        pars = [k1, k2, k3, k4, d1, d2, rfcf, ecorr]  # Set intial parameter set
        prec = np.array(data['Rainfall']) + np.array(data['Snowfall']) # Define the precipitation input
        evap = np.array(data['ActualET'])  # get the actual evapotranspiration

        # the model calculates qt+1, therefore to make it compatible with the observations, we have to
        # get rid of the last simulation result by reducing the input size
        q_sim, st_sim = sugawara.simulate(prec=prec[:-1], evap=evap[:-1], param=pars, extra_param=extra_pars)  # Run the model


        # Visualise the results
        x= np.linspace(0,1000,1000)
        p1.renderers = []
        p1.line(x ,q_sim, line_width=2, line_color='blue',legend_label= "Simulated Discharge (m^3/s)")
        p1.line(x ,Qrec, line_width=2, line_color='red', legend_label= "Recorded Discharge (m^3/s)")

        # now, instead of using a single parameter set, proceed to run the model in the MC loop
        # define the number of runs
        n_runs = int(no_runs.value)

        # Make the random sampling of the parameters using a uniform distribution. The parameters of the 
        # distribution are assigned by the designer. In this case we use a uniform distribution

        # Get the parameter bounds for the model
        bnds = sugawara.PARAM_BND

        # Make the random samples
        mc_parset = []
        for par in pars:
                mc_parset.append(np.random.uniform(0.8*par, 1.2*par, n_runs))
        mc_parset = np.array(mc_parset).T

        # run the model in the MC loop
        q_mc = []
        p2.renderers = []
        for par_i in mc_parset:
                q_sim_mc = sugawara.simulate(prec=prec[:-1], evap=evap[:-1], param=par_i, extra_param=extra_pars)[0]
                #q_mc.append(q_sim_mc)
                p2.line(x , q_sim_mc, line_width=5, line_color='lightgrey',legend_label= "MonteCarlo Simulation")
        #q_mc = np.array(q_mc).T
        p2.line(x , Qrec, line_width=2, line_color='red', legend_label= "Recorded Discharge (m^3/s)")

        p3.renderers = []
        p3.line(x , q_sim-Qrec, line_width=3, line_color='orange', legend_label= "Error from Simulation (m^3/s)")
#------------------------------------------------------LAYOUT of PAGE-------------------------------------------------------------------

# def refresh():
#      p1.renderers=[]
#      p2.renderers=[]
#      p3.renderers=[] 

# refresh_widget.on_click(refresh)

#run_widget.on_click(sug_model)
state_1.on_change('value_throttled',sug_model)
state_2.on_change('value_throttled',sug_model)
parameter_1.on_change('value_throttled',sug_model)
parameter_2.on_change('value_throttled',sug_model)
parameter_3.on_change('value_throttled',sug_model)
parameter_4.on_change('value_throttled',sug_model)

d_position_1.on_change('value_throttled',sug_model)
d_position_2.on_change('value_throttled',sug_model)
extra_param_1.on_change('value_throttled',sug_model)
extra_param_2.on_change('value_throttled',sug_model)
no_runs.on_change('value_throttled',sug_model)

input_set = Column(description_1 ,text_1, state_1, state_2, text_2, parameter_1, 
parameter_2, parameter_3, parameter_4, text_3,d_position_1,d_position_2, 
text_4, extra_param_1, extra_param_2, no_runs, width=600)

Graph = Column(text_5, p1, p3, p2, width = 500)

curdoc().add_root(Row(input_set, Graph))

# bokeh serve --show myapp-sug.py
# http://localhost:5006/myapp